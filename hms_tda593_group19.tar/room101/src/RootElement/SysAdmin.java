/**
 */
package RootElement;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sys Admin</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.RootElementPackage#getSysAdmin()
 * @model
 * @generated
 */
public interface SysAdmin extends RoomAttributeHandling, RoomHandling, RoomTypeHandling {

	

} // SysAdmin
