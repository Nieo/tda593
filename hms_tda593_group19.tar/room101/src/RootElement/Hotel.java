/**
 */
package RootElement;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hotel</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.RootElementPackage#getHotel()
 * @model
 * @generated
 */
public interface Hotel extends HotelSystem {

} // Hotel
