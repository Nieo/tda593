/**
 */
package RootElement;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hourly Room Booking</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.RootElementPackage#getHourlyRoomBooking()
 * @model
 * @generated
 */
public interface HourlyRoomBooking extends RoomBooking {
} // HourlyRoomBooking
