/**
 */
package RootElement;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Payment Handler</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.RootElementPackage#getPaymentHandler()
 * @model
 * @generated
 */
public interface PaymentHandler extends Payment {
} // PaymentHandler
